let perguntas = [

    {
        titulo: 'Top 3 dos meus jogos prediletos',
        alternativas: ['Warzone', 'Fortnite', 'The Last Of Us', 'Free Fire'],
        correta: 2
    },
    
    
    
   
    
    {
        titulo: 'Quando foi a data do nosso primeiro beijo?',
        alternativas: ['31/07', '28/07', '30/07', '29/07'],
        correta: 1
    },
    
  
    
    {
        titulo: 'Qual meu time do coração?',
        alternativas: ['Botafogo', 'Corinthians', 'Palmeiras', 'Flamengo'],
        correta: 0
    },
    
    
    
   
    
    {
        titulo: 'Pronta para a pergunta mais importante?!',
        alternativas: ['Sim', 'Não', 'Talvez', '-'],
        correta: 0
    },
    
    
    ]
    
    let app = {
        start: function(){
            this.Atualpos = 0;
            this.Totalpontos = 0;
            this.Erros = 0;
    
            let alts = document.querySelectorAll('.alternativa');
            alts.forEach((element, index)=>{
                element.addEventListener('click', ()=>{
                    this.checaResposta(index);
                })
            })
            this.atualizaPontos();
            app.mostraquestao(perguntas[this.Atualpos]);
        },
    
        mostraquestao: function(q){
            this.qatual = q;
            //mostrando titulo
            let titleDiv = document.getElementById('titulo');
            titleDiv.textContent = q.titulo;
            //mostrando alternativas
            let alts = document.querySelectorAll('.alternativa');
            alts.forEach(function(element, index){
                element.textContent = q.alternativas[index];
            })
        },
    
        checaResposta: function(user){
            if(this.qatual.correta == user){
                console.log("Correto");
                this.Totalpontos++;
            }else{
                console.log("Errado");
                this.Erros++;
            }
            this.atualizaPontos();
            this.Proximaperg();
            this.mostraquestao(perguntas[this.Atualpos]);
        },
    
        Proximaperg: function(){
            this.Atualpos++;
            if(this.Atualpos == perguntas.length){
                if(this.Totalpontos == 4){
                    location.href = "/dudoca/pdd/pedido.html";
                }else{
                    alert(`Tente novamente! Você errou um total de: ${this.Erros}`);
                    location.href = "/dudoca/quiz/quiz.html";
                }
            }
        },
    
        atualizaPontos: function(){
            let scoreDiv = document.getElementById('pontos');
            if(this.Totalpontos >= 9)
            scoreDiv.textContent = `Sua pontuação é: ${this.Totalpontos}`;
        }
    
    }
    app.start();