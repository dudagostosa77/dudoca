let perguntas = [
    {
        titulo: 'Como meu irmão chama?',
        alternativas: ['Thulio', 'Guilherme', 'Miguel', 'Lucas'],
        correta: 2
    },
    
    {
        titulo: 'Qual o nome dos meus pais?',
        alternativas: ['Rafaela e Marcel', 'Rafaela e Bruno', 'Rafaela e Junior', 'Rafaela e Joao'],
        correta: 0
    },
    
    {
        titulo: 'Top 3 dos meus jogos prediletos',
        alternativas: ['Warzone', 'Fortnite', 'The Last Of Us', 'Free Fire'],
        correta: 3
    },
    
    {
        titulo: 'Quantos animais de estimação eu tenho?',
        alternativas: ['2', '4', '5', '6'],
        correta: 0
    },
    
    {
        titulo: 'Como é meu apelido que o miguel me chama?',
        alternativas: ['Dudinha', 'Dudao', 'Irmazona', 'Duda'],
        correta: 1
    },
    
    {
        titulo: 'Quando foi a data do nosso primeiro beijo?',
        alternativas: ['01/11', '31/10', '30/10', '02/11'],
        correta: 0
    },
    
    {
        titulo: 'Quando foi a primeira vez q eu disse (eu te amo) depois que voltamos a nos falar?',
        alternativas: ['14/01', '17/01', '20/01', '13/01'],
        correta: 0
    },
    
    {
        titulo: 'Qual meu time do coração?',
        alternativas: ['Botafogo', 'Corinthians', 'Palmeiras', 'Flamengo'],
        correta: 0
    },
    
    {
        titulo: 'O que já quebrei no meu corpo?',
        alternativas: ['Punho', 'Perna', 'Joelho', 'Pé'],
        correta: 0
    },
    
    {
        titulo: 'Qual foi o primeiro versiculo q eu te dediquei?',
        alternativas: ['Corintios 13; 4-7', 'Proverbios 31;29', 'Colossenses 3;14', 'Mateus 19;6'],
        correta: 0
    },
    
    {
        titulo: 'Pronta para a pergunta mais importante?!',
        alternativas: ['Sim', 'Não', 'Talvez', '-'],
        correta: 0
    },
    
    
    ]
    
    let app = {
        start: function(){
            this.Atualpos = 0;
            this.Totalpontos = 0;
            this.Erros = 0;
    
            let alts = document.querySelectorAll('.alternativa');
            alts.forEach((element, index)=>{
                element.addEventListener('click', ()=>{
                    this.checaResposta(index);
                })
            })
            this.atualizaPontos();
            app.mostraquestao(perguntas[this.Atualpos]);
        },
    
        mostraquestao: function(q){
            this.qatual = q;
            //mostrando titulo
            let titleDiv = document.getElementById('titulo');
            titleDiv.textContent = q.titulo;
            //mostrando alternativas
            let alts = document.querySelectorAll('.alternativa');
            alts.forEach(function(element, index){
                element.textContent = q.alternativas[index];
            })
        },
    
        checaResposta: function(user){
            if(this.qatual.correta == user){
                console.log("Correto");
                this.Totalpontos++;
            }else{
                console.log("Errado");
                this.Erros++;
            }
            this.atualizaPontos();
            this.Proximaperg();
            this.mostraquestao(perguntas[this.Atualpos]);
        },
    
        Proximaperg: function(){
            this.Atualpos++;
            if(this.Atualpos == perguntas.length){
                if(this.Totalpontos == 11){
                    location.href = "/pedidooo/pedido.html";
                }else{
                    alert(`Tente novamente! Você errou um total de: ${this.Erros}`);
                    location.href = "/quiz/quiz.html";
                }
            }
        },
    
        atualizaPontos: function(){
            let scoreDiv = document.getElementById('pontos');
            if(this.Totalpontos >= 9)
            scoreDiv.textContent = `Sua pontuação é: ${this.Totalpontos}`;
        }
    
    }
    app.start();