document.addEventListener("DOMContentLoaded", () => {
    const startScreen = document.createElement("div");
    startScreen.innerHTML = `
        <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: white; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center;">
            <h1>Duda está em uma noitada e a Megan Fox quer ficar com ela! passe por cima dela e salve sua mulher!</h1>
            <button id="startGame" style="padding: 10px 20px; font-size: 20px; cursor: pointer;">Começar</button>
        </div>
    `;
    document.body.appendChild(startScreen);

    document.getElementById("startGame").addEventListener("click", () => {
        startScreen.style.display = "none";
        startGame();
    });

    function startGame() {
        const dino = document.getElementById("dino");
        const obstacle = document.getElementById("obstacle");
        let isJumping = false;
        let score = 0;
        let maxObstacles = 11;

        document.addEventListener("keydown", function(event) {
            if (event.code === "Space" && !isJumping) {
                jump();
            }
        });

        function jump() {
            isJumping = true;
            let position = 0;
            let upInterval = setInterval(() => {
                if (position >= 110) { // reduzir altura do pulo//
                    clearInterval(upInterval);
                    let downInterval = setInterval(() => {
                        if (position <= 0) {
                            clearInterval(downInterval);
                            isJumping = false;
                        }
                        position -= 1;// velocidade da descida
                        dino.style.bottom = position + "px";
                    }, ); // Acelerei o tempo do pulo
                }
                position += 2; // Acelerei o tempo do pulo
                dino.style.bottom = position + "px";
            }, 2); // Acelerei o tempo do pulo
        }

        function moveObstacle() {
            let position = 600;
            let obstacleInterval = setInterval(() => {
                if (position <= 0) {
                    position = 600;
                    score++;
                    document.getElementById("score").innerText = score;

                    if (score >= maxObstacles) {
                        alert("Você venceu! Pontuação: " + score);
                        clearInterval(obstacleInterval);
                        location.href = "/quiz/quiz.html";
                    }
                }
                position -= 5;
                obstacle.style.left = position + "px";

                if (position > 50 && position < 90 && parseInt(dino.style.bottom) <= 40) {
                    alert("Game Over! Pontuação: " + score);
                    clearInterval(obstacleInterval);
                    location.reload();
                }
            }, 20);
        }

        moveObstacle();
    }
});